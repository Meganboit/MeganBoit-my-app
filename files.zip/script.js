function askMentor() {
  const question = document.getElementById("question").value;
  const answerBox = document.getElementById("answer");

  if (!question.trim()) {
    answerBox.innerText = "Please ask a question first!";
    return;
  }

  answerBox.innerText = "Thinking deeply like Socrates... 🧠";

  // Simulated Socratic response after 2 seconds
  setTimeout(() => {
    answerBox.innerText = `That's an interesting question! Here's a thought-provoking answer: "${question}" truly makes us think about the essence of understanding.`;
  }, 2000);
}